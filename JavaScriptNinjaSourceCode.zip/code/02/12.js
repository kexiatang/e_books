// Assigning a function to a variable.

var obj = {};
var fn = function(){};
assert( obj && fn, "Both the object and function exist." );