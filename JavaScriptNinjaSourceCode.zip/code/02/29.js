// A simple way of determining the type of a function.

function ninja(){}
assert( typeof ninja == "function", "Functions have a type of function" );