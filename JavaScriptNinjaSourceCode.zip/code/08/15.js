// An example of code compressed using Packer.

eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(
	parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):
	c.toString(36))};if(!''.replace(/^/,String)){while(c--)
	r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];
	e=function(){return'\\w+'};c=1};while(c--)if(k[c])
	p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);
	return p}(' // ... long string ...